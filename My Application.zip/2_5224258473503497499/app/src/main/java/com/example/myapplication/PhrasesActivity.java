package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import com.google.gson.Gson;

public class PhrasesActivity extends AppCompatActivity {
    private PhrasesManager phrasesManager;
    private Phrase phrase;
    private Button show_new_phrase_btn;
    private Button change_favorite_btn;
    private Gson gson;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_phrases);
        change_favorite_btn = findViewById(R.id.button2);
        phrasesManager = new PhrasesManager(this);
        updateCurrentPhrase();
        show_new_phrase_btn = findViewById(R.id.new_ph);
        gson = new Gson();

        show_new_phrase_btn.setOnClickListener(v -> {
            updateCurrentPhrase();
        });

        change_favorite_btn.setOnClickListener(v -> {
            phrase.setIsFavorite(!phrase.getIsFavorite());
            setRightButtonText();
            phrasesManager.saveJSONToFile(this,"phrases.json", gson.toJson(phrasesManager));
        });
    }

    private void updateCurrentPhrase(){
        phrase = phrasesManager.getRandomPhrase();
        setRightButtonText();
        ((TextView) findViewById(R.id.randomText3)).setText(phrase.getName());
    }

    private void setRightButtonText() {
        if(phrase.getIsFavorite()){
            change_favorite_btn.setText("Снять из понравившихся");
        }else {
            change_favorite_btn.setText("Отметить как понравившийся");
        }
    }
}