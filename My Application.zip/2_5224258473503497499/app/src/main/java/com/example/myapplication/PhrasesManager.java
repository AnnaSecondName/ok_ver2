package com.example.myapplication;

import android.content.Context;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class PhrasesManager {

    @SerializedName("phrases")
    @Expose
    private List<Phrase> phrases = null;

    public PhrasesManager(Context context) {
        createJSONFile(context, "phrases.json");
        Gson gson = new Gson();
        this.phrases = gson.fromJson(readFromFile(context,"phrases.json"), PhrasesManager.class).phrases;
    }

    private void createJSONFile(Context context, String fileName){
        File path = context.getFilesDir();
        File file = new File(path, fileName);
        System.out.println(file.getAbsolutePath());
        if(!file.exists()){
            saveJSONToFile(context, fileName, JSONDataFromAsset(context,"phrases.json"));
        }
    }

    public void saveJSONToFile(Context context, String fileName, String content){
        File path = context.getFilesDir();
        FileOutputStream writer = null;
        try {
            writer = new FileOutputStream(new File(path, fileName));
            writer.write(content.getBytes());
            writer.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String JSONDataFromAsset(Context context, String fileName) {
        String json;
        try {
            InputStream inputStream = context.getAssets().open(fileName);
            int sizeOfFile = inputStream.available();
            byte[] bufferData = new byte[sizeOfFile];
            inputStream.read(bufferData);
            inputStream.close();
            json = new String(bufferData, "UTF-8");
        }catch (IOException e){
            e.printStackTrace();
            return null;
        }
        return json;
    }

    public String readFromFile(Context context, String fileName){
        File path = context.getFilesDir();
        File readFrom = new File(path, fileName);
        byte[] content = new byte[(int) readFrom.length()];
        try {
            FileInputStream stream = new FileInputStream(readFrom);
            stream.read(content);
            stream.close();
            System.out.println(new String(content));
            return new String(content);
        } catch (Exception e){
            e.printStackTrace();
            return e.toString();
        }
    }

    public List<Phrase> getPhrases() {
        return phrases;
    }

    public void setPhrases(List<Phrase> phrases) {
        this.phrases = phrases;
    }

    public Phrase getRandomPhrase() {
        int index = (int)(Math.random() * phrases.size());
        return phrases.get(index);
    }

    public Phrase getRandomFavoritePhrase() {
        int index;
        do{
            index = (int)(Math.random() * phrases.size());
        }while (!phrases.get(index).getIsFavorite());
        return phrases.get(index);
    }

    public int getFavoritePhrasesCount(){
        int count = 0;
        for(int i = 0; i < phrases.size(); ++i){
            if(phrases.get(i).getIsFavorite()){
                ++count;
            }
        }
        return count;
    }

    public Phrase[] getAllFavorite(){
        Phrase[] arr = new Phrase[getFavoritePhrasesCount()];
        int g = -1;
        for(int i = 0; i < phrases.size(); ++i){
            if(phrases.get(i).getIsFavorite()){
                arr[++g] = phrases.get(i);
            }
        }
        return arr;
    }

    public void dislikePhrase(String text) {
        for (Phrase p : phrases){
            if (p.getName().equals(text)){
                p.setIsFavorite(false);
            }
        }
    }
}