package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    private Button btn;
    private Button btnF;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ActivityCompat.requestPermissions(this, new String[] {Manifest.permission.WRITE_EXTERNAL_STORAGE
                , Manifest.permission.READ_EXTERNAL_STORAGE}, 1);
        btn = findViewById(R.id.button);
        btnF = findViewById(R.id.favorites);
        Intent i = new Intent(this, menu.class);
        Intent i1 = new Intent(this, Favorites.class);
        btnF.setOnClickListener(v ->{
            startActivity(i1);
        });

        btn.setOnClickListener(v ->{
            startActivity(i);
        });
    }
}