package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Dialog;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class FactsActivity extends AppCompatActivity {
    private FactsManager factsManager;
    private Fact fact;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_facts);
        Button more_info_btn = findViewById(R.id.more_info_btn);
        factsManager = new FactsManager(this);
        updateCurrentFact();
        Button show_new_fact_btn = findViewById(R.id.new_fact_btn);
        show_new_fact_btn.setOnClickListener(v -> updateCurrentFact());
        more_info_btn.setOnClickListener(v -> {
            Dialog dialog = new Dialog(this);
            dialog.setTitle("Подробнее о факте");
            dialog.setContentView(R.layout.dialog_view);
            TextView text = (TextView) dialog.findViewById(R.id.more_info_tv);
            text.setText(fact.getDesc());
            dialog.show();
        });
    }

    private void updateCurrentFact() {
        fact = factsManager.getRandomFact();
        ((TextView) findViewById(R.id.fact_text_tv)).setText(fact.getText());
    }
}