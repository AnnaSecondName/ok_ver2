package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;
import com.google.gson.Gson;

public class Favorites extends AppCompatActivity implements MyPhrasesAdapter.IOnItemClickListener {
    private ListView lv = null;
    private PhrasesManager PM = null;
    MyPhrasesAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorites);
        PM = new PhrasesManager(getApplicationContext());
        lv = (ListView) findViewById(R.id.list);
        updateAdapter();
    }

    @Override
    public void onMyItemClick(String text, int pos) {
        Gson gson = new Gson();
        PM.dislikePhrase(text);
        PM.saveJSONToFile(this,"phrases.json", gson.toJson(PM));
        updateAdapter();
    }

    private void updateAdapter() {
        adapter = new MyPhrasesAdapter(this, PM.getAllFavorite());
        adapter.setOnItemClickListener(this);
        lv.setAdapter(adapter);
    }
}