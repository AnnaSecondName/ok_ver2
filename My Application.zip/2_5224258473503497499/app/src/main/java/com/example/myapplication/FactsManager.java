package com.example.myapplication;

import android.content.Context;

import com.google.gson.Gson;
import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;

public class FactsManager {

    @SerializedName("facts")
    @Expose
    private List<Fact> facts = null;

    public FactsManager(Context context) {
        createJSONFile(context, "facts.json");
        Gson gson = new Gson();
        this.facts = gson.fromJson(readFromFile(context,"facts.json"), FactsManager.class).facts;
    }

    private void createJSONFile(Context context, String fileName){
        File path = context.getFilesDir();
       File file = new File(path, fileName);
        System.out.println(file.getAbsolutePath());
        saveJSONToFile(context, fileName, JSONDataFromAsset(context,"facts.json"));

   }

    public void saveJSONToFile(Context context, String fileName, String content){
        File path = context.getFilesDir();
        FileOutputStream writer = null;
        try {
            writer = new FileOutputStream(new File(path, fileName));
            writer.write(content.getBytes());
            writer.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private String JSONDataFromAsset(Context context, String fileName) {
        String json;
        try {
            InputStream inputStream = context.getAssets().open(fileName);
            int sizeOfFile = inputStream.available();
            byte[] bufferData = new byte[sizeOfFile];
            inputStream.read(bufferData);
            inputStream.close();
            json = new String(bufferData, "UTF-8");
        }catch (IOException e){
            e.printStackTrace();
            return null;
        }
        return json;
    }

    public String readFromFile(Context context, String fileName){
        File path = context.getFilesDir();
        File readFrom = new File(path, fileName);
        byte[] content = new byte[(int) readFrom.length()];
        try {
            FileInputStream stream = new FileInputStream(readFrom);
            stream.read(content);
            stream.close();
            System.out.println(new String(content));
            return new String(content);
        } catch (Exception e){
            e.printStackTrace();
            return e.toString();
        }
    }

    public Fact getRandomFact() {
        int index = (int)(Math.random() * facts.size());
        return facts.get(index);
    }

    public List<Fact> getFacts() {
        return facts;
    }

    public void setFacts(List<Fact> facts) {
        this.facts = facts;
    }
}
