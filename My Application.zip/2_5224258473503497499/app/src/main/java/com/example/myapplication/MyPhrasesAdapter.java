package com.example.myapplication;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.TextView;

public class MyPhrasesAdapter extends ArrayAdapter<Phrase> {
    class ViewHolder {
        TextView phrase_tv;
        Button dislike_btn;
    }

    public interface IOnItemClickListener {
        public void onMyItemClick(String text, int pos);
    }

    IOnItemClickListener onItemClickListener;

    public void setOnItemClickListener(IOnItemClickListener listener) {
        this.onItemClickListener = listener;
    }

    public MyPhrasesAdapter(Context context, Phrase[] arr) {
        super(context, R.layout.item_adapter_phrases, arr);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder viewHolder;
        final Phrase phrase = getItem(position);

        if (convertView == null) {
            convertView = LayoutInflater.from(getContext()).inflate(R.layout.item_adapter_phrases, null);
            viewHolder = new ViewHolder();
            viewHolder.phrase_tv = convertView.findViewById(R.id.textView2);
            viewHolder.dislike_btn = convertView.findViewById(R.id.button3);
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        viewHolder.phrase_tv.setText(getItem(position).getName());
        
        ((TextView) convertView.findViewById(R.id.textView2)).setText(phrase.getName());

        viewHolder.dislike_btn.setOnClickListener(v -> {
            if (onItemClickListener != null) {
                onItemClickListener.onMyItemClick(getItem(position).getName(), position);
            }
        });

        return convertView;
    }
}
