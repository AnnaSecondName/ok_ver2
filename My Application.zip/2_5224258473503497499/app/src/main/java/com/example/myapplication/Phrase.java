package com.example.myapplication;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Phrase {

    @SerializedName("ID")
    @Expose
    private Integer id;
    @SerializedName("isFavorite")
    @Expose
    private Boolean isFavorite;
    @SerializedName("name")
    @Expose
    private String name;

    public Phrase() {
    }

    public Phrase(Integer id, Boolean isFavorite, String name) {
        super();
        this.id = id;
        this.isFavorite = isFavorite;
        this.name = name;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Boolean getIsFavorite() {
        return isFavorite;
    }

    public void setIsFavorite(Boolean isFavorite) {
        this.isFavorite = isFavorite;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}